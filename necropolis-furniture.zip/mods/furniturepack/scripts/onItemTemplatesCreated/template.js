var ItemTemplateBuilder = Packages.org.gotti.wurmunlimited.modsupport.ItemTemplateBuilder;
var ItemTypes = Packages.com.wurmonline.server.items.ItemTypes;
var logger = Packages.java.util.logging.Logger.getLogger("nekropolis.furniture");

function onItemTemplatesCreated() {

	var redarmchair = new ItemTemplateBuilder("nekropolis.furniture.redarmchair");
	redarmchair.name("armchair (red)", "armchairs (red)", "A red armchair");
	redarmchair.descriptions("excellent", "good", "ok", "poor");
	redarmchair.itemTypes([ 
		ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	redarmchair.imageNumber(274);
	redarmchair.behaviourType(41);
	redarmchair.combatDamage(0);
	redarmchair.decayTime(9072000);
	redarmchair.dimensions(10, 30, 60);
	redarmchair.primarySkill(-10);
	redarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	redarmchair.modelName("nekropolis.furniture.redarmchair.");
	redarmchair.difficulty(10.0);
	redarmchair.weightGrams(7000);
	redarmchair.material(14);
	redarmchair.isTraded(true);
	var templatered = redarmchair.build();
	logger.info("Created item template " + templatered.getTemplateId() + " for armchair (red)");
	
	var bluearmchair = new ItemTemplateBuilder("nekropolis.furniture.bluearmchair");
	bluearmchair.name("armchair (blue)", "armchairs (blue)", "A blue armchair");
	bluearmchair.descriptions("excellent", "good", "ok", "poor");
	bluearmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	bluearmchair.imageNumber(274);
	bluearmchair.behaviourType(41);
	bluearmchair.combatDamage(0);
	bluearmchair.decayTime(9072000);
	bluearmchair.dimensions(10, 30, 60);
	bluearmchair.primarySkill(-10);
	bluearmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	bluearmchair.modelName("nekropolis.furniture.bluearmchair.");
	bluearmchair.difficulty(10.0);
	bluearmchair.weightGrams(7000);
	bluearmchair.material(14);
	bluearmchair.isTraded(true);
	var templateblue = bluearmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (blue)");

	
		var rainarmchair = new ItemTemplateBuilder("nekropolis.furniture.rainarmchair");
	rainarmchair.name("armchair (rain)", "armchairs (rain)", "A rain armchair");
	rainarmchair.descriptions("excellent", "good", "ok", "poor");
	rainarmchair.itemTypes([ 
		ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	rainarmchair.imageNumber(274);
	rainarmchair.behaviourType(41);
	rainarmchair.combatDamage(0);
	rainarmchair.decayTime(9072000);
	rainarmchair.dimensions(10, 30, 60);
	rainarmchair.primarySkill(-10);
	rainarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	rainarmchair.modelName("nekropolis.furniture.rainarmchair.");
	rainarmchair.difficulty(10.0);
	rainarmchair.weightGrams(7000);
	rainarmchair.material(14);
	rainarmchair.isTraded(true);
	var templaterain = rainarmchair.build();
	logger.info("Created item template " + templaterain.getTemplateId() + " for armchair (rain)");


	var beerarmchair = new ItemTemplateBuilder("nekropolis.furniture.beerarmchair");
	beerarmchair.name("armchair (beer)", "armchairs (beer)", "A beer armchair");
	beerarmchair.descriptions("excellent", "good", "ok", "poor");
	beerarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	beerarmchair.imageNumber(274);
	beerarmchair.behaviourType(41);
	beerarmchair.combatDamage(0);
	beerarmchair.decayTime(9072000);
	beerarmchair.dimensions(10, 30, 60);
	beerarmchair.primarySkill(-10);
	beerarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	beerarmchair.modelName("nekropolis.furniture.beerarmchair.");
	beerarmchair.difficulty(10.0);
	beerarmchair.weightGrams(7000);
	beerarmchair.material(14);
	beerarmchair.isTraded(true);
	var templatebeer = beerarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (beer)");
	
	
		var autumnarmchair = new ItemTemplateBuilder("nekropolis.furniture.autumnarmchair");
	autumnarmchair.name("armchair (autumn)", "armchairs (autumn)", "A autumn armchair");
	autumnarmchair.descriptions("excellent", "good", "ok", "poor");
	autumnarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	autumnarmchair.imageNumber(274);
	autumnarmchair.behaviourType(41);
	autumnarmchair.combatDamage(0);
	autumnarmchair.decayTime(9072000);
	autumnarmchair.dimensions(10, 30, 60);
	autumnarmchair.primarySkill(-10);
	autumnarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	autumnarmchair.modelName("nekropolis.furniture.autumnarmchair.");
	autumnarmchair.difficulty(10.0);
	autumnarmchair.weightGrams(7000);
	autumnarmchair.material(14);
	autumnarmchair.isTraded(true);
	var templateautumn = autumnarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (autumn)");
	
		var bayrischarmchair = new ItemTemplateBuilder("nekropolis.furniture.bayrischarmchair");
	bayrischarmchair.name("armchair (bayrisch)", "armchairs (bayrisch)", "A bayrisch armchair");
	bayrischarmchair.descriptions("excellent", "good", "ok", "poor");
	bayrischarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	bayrischarmchair.imageNumber(274);
	bayrischarmchair.behaviourType(41);
	bayrischarmchair.combatDamage(0);
	bayrischarmchair.decayTime(9072000);
	bayrischarmchair.dimensions(10, 30, 60);
	bayrischarmchair.primarySkill(-10);
	bayrischarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	bayrischarmchair.modelName("nekropolis.furniture.bayrischarmchair.");
	bayrischarmchair.difficulty(10.0);
	bayrischarmchair.weightGrams(7000);
	bayrischarmchair.material(14);
	bayrischarmchair.isTraded(true);
	var templatebayrisch = bayrischarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (bayrisch)");
	
		var blackwoolarmchair = new ItemTemplateBuilder("nekropolis.furniture.blackwoolarmchair");
	blackwoolarmchair.name("armchair (blackwool)", "armchairs (blackwool)", "A blackwool armchair");
	blackwoolarmchair.descriptions("excellent", "good", "ok", "poor");
	blackwoolarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	blackwoolarmchair.imageNumber(274);
	blackwoolarmchair.behaviourType(41);
	blackwoolarmchair.combatDamage(0);
	blackwoolarmchair.decayTime(9072000);
	blackwoolarmchair.dimensions(10, 30, 60);
	blackwoolarmchair.primarySkill(-10);
	blackwoolarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	blackwoolarmchair.modelName("nekropolis.furniture.blackwoolarmchair.");
	blackwoolarmchair.difficulty(10.0);
	blackwoolarmchair.weightGrams(7000);
	blackwoolarmchair.material(14);
	blackwoolarmchair.isTraded(true);
	var templateblackwool = blackwoolarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (blackwool)");
	
		var bluesquarearmchair = new ItemTemplateBuilder("nekropolis.furniture.bluesquarearmchair");
	bluesquarearmchair.name("armchair (bluesquare)", "armchairs (bluesquare)", "A bluesquare armchair");
	bluesquarearmchair.descriptions("excellent", "good", "ok", "poor");
	bluesquarearmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	bluesquarearmchair.imageNumber(274);
	bluesquarearmchair.behaviourType(41);
	bluesquarearmchair.combatDamage(0);
	bluesquarearmchair.decayTime(9072000);
	bluesquarearmchair.dimensions(10, 30, 60);
	bluesquarearmchair.primarySkill(-10);
	bluesquarearmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	bluesquarearmchair.modelName("nekropolis.furniture.bluesquarearmchair.");
	bluesquarearmchair.difficulty(10.0);
	bluesquarearmchair.weightGrams(7000);
	bluesquarearmchair.material(14);
	bluesquarearmchair.isTraded(true);
	var templatebluesquare = bluesquarearmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (bluesquare)");
	
		var deluxearmchair = new ItemTemplateBuilder("nekropolis.furniture.deluxearmchair");
	deluxearmchair.name("armchair (deluxe)", "armchairs (deluxe)", "A deluxe armchair");
	deluxearmchair.descriptions("excellent", "good", "ok", "poor");
	deluxearmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	deluxearmchair.imageNumber(274);
	deluxearmchair.behaviourType(41);
	deluxearmchair.combatDamage(0);
	deluxearmchair.decayTime(9072000);
	deluxearmchair.dimensions(10, 30, 60);
	deluxearmchair.primarySkill(-10);
	deluxearmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	deluxearmchair.modelName("nekropolis.furniture.deluxearmchair.");
	deluxearmchair.difficulty(10.0);
	deluxearmchair.weightGrams(7000);
	deluxearmchair.material(14);
	deluxearmchair.isTraded(true);
	var templatedeluxe = deluxearmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (deluxe)");
	
		var fancyarmchair = new ItemTemplateBuilder("nekropolis.furniture.fancyarmchair");
	fancyarmchair.name("armchair (fancy)", "armchairs (fancy)", "A fancy armchair");
	fancyarmchair.descriptions("excellent", "good", "ok", "poor");
	fancyarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	fancyarmchair.imageNumber(274);
	fancyarmchair.behaviourType(41);
	fancyarmchair.combatDamage(0);
	fancyarmchair.decayTime(9072000);
	fancyarmchair.dimensions(10, 30, 60);
	fancyarmchair.primarySkill(-10);
	fancyarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	fancyarmchair.modelName("nekropolis.furniture.fancyarmchair.");
	fancyarmchair.difficulty(10.0);
	fancyarmchair.weightGrams(7000);
	fancyarmchair.material(14);
	fancyarmchair.isTraded(true);
	var templatefancy = fancyarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (fancy)");
	
		var grandmaarmchair = new ItemTemplateBuilder("nekropolis.furniture.grandmaarmchair");
	grandmaarmchair.name("armchair (grandma)", "armchairs (grandma)", "A grandma armchair");
	grandmaarmchair.descriptions("excellent", "good", "ok", "poor");
	grandmaarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	grandmaarmchair.imageNumber(274);
	grandmaarmchair.behaviourType(41);
	grandmaarmchair.combatDamage(0);
	grandmaarmchair.decayTime(9072000);
	grandmaarmchair.dimensions(10, 30, 60);
	grandmaarmchair.primarySkill(-10);
	grandmaarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	grandmaarmchair.modelName("nekropolis.furniture.grandmaarmchair.");
	grandmaarmchair.difficulty(10.0);
	grandmaarmchair.weightGrams(7000);
	grandmaarmchair.material(14);
	grandmaarmchair.isTraded(true);
	var templategrandma = grandmaarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (grandma)");
	
		var greenarmchair = new ItemTemplateBuilder("nekropolis.furniture.greenarmchair");
	greenarmchair.name("armchair (green)", "armchairs (green)", "A green armchair");
	greenarmchair.descriptions("excellent", "good", "ok", "poor");
	greenarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	greenarmchair.imageNumber(274);
	greenarmchair.behaviourType(41);
	greenarmchair.combatDamage(0);
	greenarmchair.decayTime(9072000);
	greenarmchair.dimensions(10, 30, 60);
	greenarmchair.primarySkill(-10);
	greenarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	greenarmchair.modelName("nekropolis.furniture.greenarmchair.");
	greenarmchair.difficulty(10.0);
	greenarmchair.weightGrams(7000);
	greenarmchair.material(14);
	greenarmchair.isTraded(true);
	var templategreen = greenarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (green)");
	
		var noblearmchair = new ItemTemplateBuilder("nekropolis.furniture.noblearmchair");
	noblearmchair.name("armchair (noble)", "armchairs (noble)", "A noble armchair");
	noblearmchair.descriptions("excellent", "good", "ok", "poor");
	noblearmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	noblearmchair.imageNumber(274);
	noblearmchair.behaviourType(41);
	noblearmchair.combatDamage(0);
	noblearmchair.decayTime(9072000);
	noblearmchair.dimensions(10, 30, 60);
	noblearmchair.primarySkill(-10);
	noblearmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	noblearmchair.modelName("nekropolis.furniture.noblearmchair.");
	noblearmchair.difficulty(10.0);
	noblearmchair.weightGrams(7000);
	noblearmchair.material(14);
	noblearmchair.isTraded(true);
	var templatenoble = noblearmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " for armchair (noble)");
	
		var oldarmchair = new ItemTemplateBuilder("nekropolis.furniture.oldarmchair");
	oldarmchair.name("armchair (old)", "armchairs (old)", "A old armchair");
	oldarmchair.descriptions("excellent", "good", "ok", "poor");
	oldarmchair.itemTypes([ 
	ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_VEHICLE,
		ItemTypes.ITEM_TYPE_CHAIR,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	oldarmchair.imageNumber(274);
	oldarmchair.behaviourType(41);
	oldarmchair.combatDamage(0);
	oldarmchair.decayTime(9072000);
	oldarmchair.dimensions(10, 30, 60);
	oldarmchair.primarySkill(-10);
	oldarmchair.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	oldarmchair.modelName("nekropolis.furniture.oldarmchair.");
	oldarmchair.difficulty(10.0);
	oldarmchair.weightGrams(7000);
	oldarmchair.material(14);
	oldarmchair.isTraded(true);
	var templateold = oldarmchair.build();
	logger.info("Created item template " + templateblue.getTemplateId() + " old armchair");
	
	var necrobanner = new ItemTemplateBuilder("nekropolis.furniture.necrobanner");
	necrobanner.name("Necropolis tall banner", "Necropolis tall banner", "The server tall banner");
	necrobanner.descriptions("excellent", "good", "ok", "poor");
	necrobanner.itemTypes([ 
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	necrobanner.imageNumber(274);
	necrobanner.behaviourType(41);
	necrobanner.combatDamage(0);
	necrobanner.decayTime(9072000);
	necrobanner.dimensions(10, 30, 60);
	necrobanner.primarySkill(-10);
	necrobanner.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	necrobanner.modelName("nekropolis.furniture.necrobanner.");
	necrobanner.difficulty(10.0);
	necrobanner.weightGrams(7000);
	necrobanner.material(14);
	necrobanner.isTraded(true);
	var templatenecro = necrobanner.build();
	logger.info("Created item template " + templatenecro.getTemplateId() + " for Necropolis tall banner");
	
	var tombbanner = new ItemTemplateBuilder("nekropolis.furniture.tombbanner");
	tombbanner.name("Necropolis Tombola banner", "Necropolis Tombola banner", "The server tombola banner");
	tombbanner.descriptions("excellent", "good", "ok", "poor");
	tombbanner.itemTypes([ 
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_PLANTABLE]);
	tombbanner.imageNumber(274);
	tombbanner.behaviourType(41);
	tombbanner.combatDamage(0);
	tombbanner.decayTime(9072000);
	tombbanner.dimensions(10, 30, 60);
	tombbanner.primarySkill(-10);
	tombbanner.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	tombbanner.modelName("nekropolis.furniture.tombbanner.");
	tombbanner.difficulty(10.0);
	tombbanner.weightGrams(7000);
	tombbanner.material(14);
	tombbanner.isTraded(true);
	var templatetomb = tombbanner.build();
	logger.info("Created item template " + templatetomb.getTemplateId() + " for Necropolis tombola banner");
}


