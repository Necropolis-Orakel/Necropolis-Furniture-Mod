var IdFactory = Packages.org.gotti.wurmunlimited.modsupport.IdFactory;
var IdType = Packages.org.gotti.wurmunlimited.modsupport.IdType;
var CreationCategories = Packages.com.wurmonline.server.items.CreationCategories;
var ItemList = Packages.com.wurmonline.server.items.ItemList;
var SkillList = Packages.com.wurmonline.server.skills.SkillList;
var CreationEntryCreator = Packages.com.wurmonline.server.items.CreationEntryCreator;
var logger = Packages.java.util.logging.Logger.getLogger("nekropolis.furniture");
var CreationRequirement = Packages.com.wurmonline.server.items.CreationRequirement;

function onServerStarted() {
	var armchair_red = IdFactory.getIdFor("nekropolis.furniture.redarmchair", IdType.ITEMTEMPLATE);
	var armchair_red_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_red, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_red_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_red_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_red_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (red)");
	
	var armchair_blue = IdFactory.getIdFor("nekropolis.furniture.bluearmchair", IdType.ITEMTEMPLATE);
	var armchair_blue_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_blue, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_blue_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_blue_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_blue_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (blue)");
	
	var armchair_rain = IdFactory.getIdFor("nekropolis.furniture.rainarmchair", IdType.ITEMTEMPLATE);
	var armchair_rain_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_rain, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_rain_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_rain_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_rain_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (rain)");

	var armchair_beer = IdFactory.getIdFor("nekropolis.furniture.beerarmchair", IdType.ITEMTEMPLATE);
	var armchair_beer_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_beer, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_beer_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_beer_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_beer_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (beer)");
	
	var armchair_autumn = IdFactory.getIdFor("nekropolis.furniture.autumnarmchair", IdType.ITEMTEMPLATE);
	var armchair_autumn_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_autumn, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_autumn_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_autumn_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_autumn_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (autumn)");
	
	var armchair_bayrisch = IdFactory.getIdFor("nekropolis.furniture.bayrischarmchair", IdType.ITEMTEMPLATE);
	var armchair_bayrisch_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_bayrisch, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_bayrisch_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_bayrisch_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_bayrisch_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (bayrisch)");
	
	var armchair_blackwool = IdFactory.getIdFor("nekropolis.furniture.blackwoolarmchair", IdType.ITEMTEMPLATE);
	var armchair_blackwool_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_blackwool, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_blackwool_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_blackwool_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_blackwool_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (blackwool)");
	
	var armchair_bluesquare = IdFactory.getIdFor("nekropolis.furniture.bluesquarearmchair", IdType.ITEMTEMPLATE);
	var armchair_bluesquare_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_bluesquare, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_bluesquare_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_bluesquare_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_bluesquare_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (bluesquare)");
	
	var armchair_deluxe = IdFactory.getIdFor("nekropolis.furniture.deluxearmchair", IdType.ITEMTEMPLATE);
	var armchair_deluxe_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_deluxe, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_deluxe_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_deluxe_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_deluxe_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (deluxe)");
	
	var armchair_fancy = IdFactory.getIdFor("nekropolis.furniture.fancyarmchair", IdType.ITEMTEMPLATE);
	var armchair_fancy_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_fancy, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_fancy_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_fancy_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_fancy_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (fancy)");
	
	var armchair_grandma = IdFactory.getIdFor("nekropolis.furniture.grandmaarmchair", IdType.ITEMTEMPLATE);
	var armchair_grandma_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_grandma, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_grandma_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_grandma_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_grandma_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (grandma)");
	
	var armchair_green = IdFactory.getIdFor("nekropolis.furniture.greenarmchair", IdType.ITEMTEMPLATE);
	var armchair_green_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_green, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_green_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_green_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_green_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (green)");
	
	var armchair_noble = IdFactory.getIdFor("nekropolis.furniture.noblearmchair", IdType.ITEMTEMPLATE);
	var armchair_noble_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_noble, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_noble_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_noble_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_noble_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (noble)");
	
	var armchair_old = IdFactory.getIdFor("nekropolis.furniture.oldarmchair", IdType.ITEMTEMPLATE);
	var armchair_old_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, armchair_old, false, false, 0.0 , true, true, 0, 50.0, CreationCategories.FURNITURE);
	    armchair_old_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        armchair_old_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        armchair_old_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for armchair (old)");
	logger.info("Creation of all armchairs finished!");
}